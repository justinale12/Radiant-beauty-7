<?php 

/* Template Name: Front Page Template */

get_header(); 

omega_jewelry_store_main_slider();
omega_jewelry_store_product_section();

get_footer(); ?>